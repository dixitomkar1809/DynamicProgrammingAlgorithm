Python 3.6.4 (v3.6.4:d48eceb, Dec 19 2017, 06:04:45)

if python is installed globally then 
	copy the ond170030Project6363.py

if pyhton is installed in specific directory then
	copy the ond170030Project6363.py file to that directory 

and then run the following commands
	python ond170030Project6363.py		// give the input outputs maximum profit and number of optimal solutions
	python ond170030Project6363.py - 	//give the input outputs maximum profit and number of optimal solutions
	python ond170030Project6363.py input.txt	//takes input from input.txt and outputs the maximum profit and number of optimal solutions	
	python ond170030Project6363.py input.txt 0 // this shows the maximum profit and number of solutions from input.txt file
	python ond170030Project6363.py input.txt 1 //this shows the list of optimal values with maximum profit and number of optimal solutions from input.txt

some files may take time to execute, smaller ones get executed quickly to show the output


Collaborators -> Yash Pradhan and Tushar Chemburkar